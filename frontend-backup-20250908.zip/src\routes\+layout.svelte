<script lang="ts">
	import { onMount } from 'svelte';
	import { goto } from '$app/navigation';
	import { authStore } from '$stores/auth';
	import Header from '$components/Header.svelte';
	import Sidebar from '$components/Sidebar.svelte';
	import Toast from '$components/Toast.svelte';
	import { toastStore } from '$stores/toast';

	let { children } = $props();
	let sidebarOpen = $state(false);

	onMount(() => {
		// Initialize auth state from localStorage
		authStore.initialize();
	});

	function toggleSidebar() {
		sidebarOpen = !sidebarOpen;
	}

	function closeSidebar() {
		sidebarOpen = false;
	}
</script>

<div class="min-h-screen bg-gray-50">
	{#if $authStore.isAuthenticated}
		<!-- Authenticated Layout -->
		<div class="flex h-screen">
			<!-- Sidebar -->
			<Sidebar bind:open={sidebarOpen} onClose={closeSidebar} />
			
			<!-- Main Content -->
			<div class="flex-1 flex flex-col overflow-hidden">
				<Header onMenuClick={toggleSidebar} />
				
				<main class="flex-1 overflow-auto p-6">
					{@render children()}
				</main>
			</div>
		</div>
	{:else}
		<!-- Public Layout -->
		<main class="min-h-screen">
			{@render children()}
		</main>
	{/if}

	<!-- Toast Notifications -->
	{#if $toastStore}
		<Toast />
	{/if}
</div>
