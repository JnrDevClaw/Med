<script lang="ts">
	import { onMount } from 'svelte';
	import { goto } from '$app/navigation';
	import { authStore } from '$stores/auth';

	onMount(() => {
		// Redirect based on authentication status
		if ($authStore.isAuthenticated) {
			goto('/dashboard');
		} else {
			goto('/auth/login');
		}
	});
</script>

<svelte:head>
	<title>MedPlatform - Decentralized Healthcare</title>
	<meta name="description" content="Secure, decentralized healthcare platform with AI assistance and video consultations" />
</svelte:head>

<!-- Loading state while redirecting -->
<div class="min-h-screen bg-gradient-to-br from-primary-50 to-secondary-100 flex items-center justify-center">
	<div class="text-center">
		<div class="w-16 h-16 bg-primary-600 rounded-xl flex items-center justify-center mx-auto mb-4">
			<span class="text-white font-bold text-xl">MP</span>
		</div>
		<div class="spinner w-8 h-8 mx-auto mb-4"></div>
		<p class="text-gray-600">Loading MedPlatform...</p>
	</div>
</div>
