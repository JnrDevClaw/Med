<script lang="ts">
	interface Props {
		class?: string;
		size?: number;
	}
	
	let { class: className = '', size = 24 }: Props = $props();
</script>

<svg
	class={className}
	width={size}
	height={size}
	viewBox="0 0 24 24"
	fill="none"
	stroke="currentColor"
	stroke-width="2"
	stroke-linecap="round"
	stroke-linejoin="round"
>
	<path d="M4.8 2.3A.3.3 0 0 0 5 2.5v1.9a.3.3 0 0 0-.3.3v1.7c0 1.8 1.4 3.2 3.2 3.2s3.2-1.4 3.2-3.2V4.7a.3.3 0 0 0-.3-.3V2.5a.3.3 0 0 0 .2-.2"/>
	<circle cx="11" cy="3" r="2"/>
	<path d="M10.5 21.5V18c0-2.5 2-4.5 4.5-4.5h0c2.5 0 4.5 2 4.5 4.5v3.5"/>
	<circle cx="15" cy="9" r="4"/>
	<path d="M2 18.5C2 16 4 14 6.5 14S11 16 11 18.5"/>
</svg>
