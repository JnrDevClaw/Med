import '../app.css';

export const prerender = false;
export const ssr = false;
