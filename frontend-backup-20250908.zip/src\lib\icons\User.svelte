<script lang="ts">
	interface Props {
		class?: string;
		size?: number;
	}
	
	let { class: className = '', size = 24 }: Props = $props();
</script>

<svg
	class={className}
	width={size}
	height={size}
	viewBox="0 0 24 24"
	fill="none"
	stroke="currentColor"
	stroke-width="2"
	stroke-linecap="round"
	stroke-linejoin="round"
>
	<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
	<circle cx="12" cy="7" r="4"/>
</svg>
